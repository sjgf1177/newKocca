<!--

var checkz = "0"

function map() {
openwin=window.open("map.html","newwindow1","toolbar=no,scrollbars=no,location=no,status=no,menubar=no,resizable=no,width=800,height=600")
}


function win2(pPage,t,a,b,sc) {
window.open(pPage,t,'width='+a+' height='+b+',scrollbars='+sc+',status=no');
}


function whenSubmits() {			//�ǰ�����
	if(document.ff.p_content.value.length<2) {
		alert("������ �ݵ�� �Է��ϼž� �մϴ�.");
		return;
	}
	document.ff.submit();
}

function whenOpList() {				//�ٸ� ����ǰߺ���
	var url = '/plsql/cyber/edu_opin.list?p_opseq='+document.ff.p_opseq.value;
	window.open(url,"","toolbar=no,statusbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=600,height=500").focus();
}

function getCookieVal (offset) {  
	 var endstr = document.cookie.indexOf (";", offset); 
	 if (endstr == -1)    
	  endstr = document.cookie.length;  
	  return unescape(document.cookie.substring(offset, endstr));
}

function GetCookie(name) {  
	 var arg = name + "=";  
	 var alen = arg.length;  
	 var clen = document.cookie.length;  
	 var i = 0;  
	 while (i < clen) {    
	  var j = i + alen;    
	  if (document.cookie.substring(i, j) == arg)  
	   return getCookieVal (j);    
	  i = document.cookie.indexOf(" ", i) + 1;    
	  if (i == 0) break;
	 }  
	 return '�մ�';
}


function Popup(url) {	
			if (document.form_print.yy.value == "") {
				alert('������ �Է��� �ּ���.');
			} else {
				                                          window.open(url,'','width=566,height=480,scrollbars=yes');
			}
		}


function go_testzoo(){
		if(checkz == "0"){
		ff.p_content.value = "";
		checkz = "1";
	}
}

function go_testprint(){
		if(checkz == "0"){
		form_print.yy.value = "";
		checkz = "1";
	}

}


function na_show_layer(lname, flag)
{
  var layer = (navigator.appName == 'Netscape') ? document.layers[lname] : document.all[lname];
  if (lname == '')
    return;
  if (navigator.appName == 'Netscape')
    layer.visibility = (flag == 0) ? 'show' : 'hide';
  else
    layer.style.visibility = (flag == 0) ? 'visible' : 'hidden';
}
-->