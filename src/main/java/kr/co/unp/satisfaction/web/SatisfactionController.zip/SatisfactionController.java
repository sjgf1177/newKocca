package kr.co.funnywork.satisfaction.web;

import java.net.URLEncoder;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.View;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.utl.sim.service.EgovClntInfo;
import kr.co.funnywork.mpm.service.MasterMenuManager;
import kr.co.funnywork.satisfaction.service.impl.SatisfactionServiceImpl;
import kr.co.funnywork.util.PageUtil;
import kr.co.funnywork.util.WebFactory;
import kr.co.funnywork.util.ZValue;
import egovframework.rte.fdl.property.EgovPropertyService;

@Controller
public class SatisfactionController
{    
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertyService;
    
	@Resource(name="satisfactionService")
	private SatisfactionServiceImpl satisfactionService;

	@Resource(name = "webFactory") 
	private WebFactory WebFactory;

    @Resource(name = "pageUtil")
    protected PageUtil PageUtil;

    @Resource(name = "masterMenuManagerService")
    protected MasterMenuManager masterMenuManagerService;
    
    @Resource(name = "excelGenerateView")
    protected View excelGenerateView;

	@RequestMapping("/portal/satisfaction/save.do")
	public void saveSatisfaction(
			HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model)
			throws Exception
	{
    	ZValue zvl = WebFactory.getAttributes(request);
    	
		String resultMsg = null;
    	String userIp = EgovClntInfo.getClntIP(request);
    	zvl.put("userKey", userIp);
    	
    	if(satisfactionService.existsUserIp(zvl) > 0)
    	{
    		resultMsg = "이미 참여하셨습니다.";
    	}
    	else
    	{
    		resultMsg = "만족도 평가에 참여해 주셔서 감사합니다.";
    		satisfactionService.saveSatisfaction(zvl);
    	}
    	
		WebFactory.printHtml(response, resultMsg, "javascript:history.back()");
				
	}

	@RequestMapping("/bos/satisfaction/statusView")
	public String statusView(
			HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model)
			throws Exception
	{		
    	ZValue zvl = WebFactory.getAttributes(request);
    	satisfactionService.selectStatusView(zvl, model);
		return "bos/satisfaction/statusView";
	}
	
	@RequestMapping("/bos/satisfaction/menuStatusView")
	public String menuStatusView(
			HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model)
			throws Exception
	{		
    	ZValue zvl = WebFactory.getAttributes(request);
    	satisfactionService.selectStatusView(zvl, model);
		return "bos/satisfaction/menuStatusView";
	}
	
	@RequestMapping("/bos/satisfaction/menuStatusList")
	public String menuStatusList(
			HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model)
			throws Exception
	{		
    	ZValue zvl = WebFactory.getAttributes(request);
    	satisfactionService.selectStatusList(zvl, model);
		return "bos/satisfaction/menuStatusList";
	}
	
	@RequestMapping("/bos/satisfaction/opinionList/{status}")
	public String opinionList(
			@PathVariable String status,
			HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model)
			throws Exception
	{
    	ZValue zvl = WebFactory.getAttributes(request);

		ZValue pageInfo = PageUtil.getJnPaginationInfo(zvl);
		zvl.put("status", status);
		Map<String, Object> map = satisfactionService.selectOpinionList(zvl);
		int totCnt = Integer.parseInt((String)map.get("resultCnt"));
    	zvl.put("totCnt", totCnt);

    	String link = 
    		"/bos/satisfaction/opinionList?" +
    		"siteId="+zvl.getString("siteId")+
    		"&searchType="+zvl.getString("searchType")+
    		"&searchTxt="+URLEncoder.encode(zvl.getString("searchTxt"),"UTF-8");
    	zvl.put("link", link);
		
		String pageNav = PageUtil.getJnPageNavString(pageInfo);

		model.addAttribute("resultList", map.get("resultList"));
		model.addAttribute("resultCnt", map.get("resultCnt"));
		model.addAttribute("zvl", zvl);
		model.addAttribute("pageNav", pageNav);
		
		return "bos/satisfaction/opinionList";
	}
	
	@RequestMapping("/bos/satisfaction/menuStatusListExcel")
	public ModelAndView satisfactionExcel(
			final HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model)
			throws Exception {

		ZValue zvl = WebFactory.getAttributes(request);
    	
    	satisfactionService.menuStatusListExcel(zvl, model);
		
    	ModelAndView modelMap = new ModelAndView(excelGenerateView);
    	modelMap.addAllObjects(model);
    	return modelMap;
		
	}
}
